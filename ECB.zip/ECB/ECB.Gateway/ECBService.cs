﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using ECB.API.Entities;
using Microsoft.Extensions.Configuration;

namespace ECB.GateWay
  {
  public class ECBService : IECBService
    {
    private readonly string EcbUrl;
    private readonly HttpClient EcbHttpClient;

    public ECBService(HttpClient httpClient, IConfiguration configuration)
      {
      EcbHttpClient = httpClient;
      EcbUrl = configuration["EcbUrl"];
      }

    public async Task<List<CurrencyRate>> GetExchangeRatesAsync()
      {
      using (var EcbHttpClient = new HttpClient())
        {
        HttpResponseMessage response = await EcbHttpClient.GetAsync(EcbUrl);
        response.EnsureSuccessStatusCode();
        string xmlContent = await response.Content.ReadAsStringAsync();
        return ParseExchangeRates(xmlContent);
        }
      }

    private List<CurrencyRate> ParseExchangeRates(string xmlContent)
      {
      List<CurrencyRate> rates = new List<CurrencyRate>();
      XDocument doc = XDocument.Parse(xmlContent);

      XNamespace ecb = "http://www.ecb.int/vocabulary/2002-08-01/eurofxref";
      // Find the Cube element with the time attribute
      XElement? cubeRoot = doc.Descendants(ecb + "Cube")
                              .FirstOrDefault(c => c.Attribute("time") != null);

      if (cubeRoot != null)
        {
        DateTime date = DateTime.Parse(cubeRoot.Attribute("time")?.Value ?? DateTime.UtcNow.ToString("yyyy-MM-dd"));
        foreach (XElement cube in cubeRoot.Elements(ecb + "Cube"))
          {
          string currency = cube.Attribute("currency")?.Value ?? string.Empty;
          string rateStr = cube.Attribute("rate")?.Value ?? "0";
          if (decimal.TryParse(rateStr, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal rate))
            {
            rates.Add(new CurrencyRate(currency, rate, date));
            }
          }
        }
      return rates;
      }
    }
  }
