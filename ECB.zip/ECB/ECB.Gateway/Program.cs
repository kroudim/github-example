﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using ECB.GateWay;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

class Program
  {
  static async Task Main(string[] args)
    {
    var host = CreateHostBuilder(args).Build();

    // Resolve ECBService and call GetExchangeRatesAsync
    var ecbService = host.Services.GetRequiredService<ECBService>();
    var rates = await ecbService.GetExchangeRatesAsync();

    // Print the exchange rates
    foreach (var rate in rates)
      {
      Console.WriteLine($"Currency: {rate.Currency}, Rate: {rate.Rate}, Date: {rate.Date}");
      }
    }

  static IHostBuilder CreateHostBuilder(string[] args) =>
      Host.CreateDefaultBuilder(args)
          .ConfigureAppConfiguration((hostingContext, config) =>
          {
            config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
          })
          .ConfigureServices((context, services) =>
          {
            services.AddHttpClient<ECBService>();
            services.AddSingleton<ECBService>(provider =>
            {
              var httpClient = provider.GetRequiredService<IHttpClientFactory>().CreateClient();
              var configuration = provider.GetRequiredService<IConfiguration>();
              return new ECBService(httpClient, configuration);
            });
          });
  }
