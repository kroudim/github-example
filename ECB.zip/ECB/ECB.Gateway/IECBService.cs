﻿using ECB.API.Entities;

public interface IECBService
  {
  Task<List<CurrencyRate>> GetExchangeRatesAsync();
  }