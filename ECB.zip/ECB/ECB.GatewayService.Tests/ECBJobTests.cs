﻿using ECB.API.Entities;
using ECB.WorkerService;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

public class ECBJobTests
  {
  private readonly Mock<ILogger<ECBJob>> _loggerMock;
  private readonly Mock<IECBService> _ecbServiceMock;
  private readonly Mock<IDatabaseService> _databaseServiceMock;
  private readonly ECBJob _ecbJob;
  private readonly double _interval = 1.0; // 1 minute

  public ECBJobTests()
    {
    _loggerMock = new Mock<ILogger<ECBJob>>();
    _ecbServiceMock = new Mock<IECBService>();
    _databaseServiceMock = new Mock<IDatabaseService>();
    _ecbJob = new ECBJob(_loggerMock.Object, _ecbServiceMock.Object, _databaseServiceMock.Object, _interval);
    }

  [Fact]
  public async Task UpdateDatabaseAsync_ShouldUpdateDatabaseWithRates()
    {
    // Arrange
    var rates = new List<CurrencyRate>
        {
            new CurrencyRate("USD", 1.0360m, DateTime.Now),
            new CurrencyRate("JPY", 157.95m, DateTime.Now)
        };

    _databaseServiceMock.Setup(db => db.OpenConnectionAsync()).Returns(Task.CompletedTask);
    _databaseServiceMock.Setup(db => db.BeginTransactionAsync()).Returns(Task.CompletedTask);
    _databaseServiceMock.Setup(db => db.CommitTransactionAsync()).Returns(Task.CompletedTask);
    _databaseServiceMock.Setup(db => db.RollbackTransactionAsync()).Returns(Task.CompletedTask);
    _databaseServiceMock.Setup(db => db.ExecuteNonQueryAsync(It.IsAny<string>(), It.IsAny<SqlParameter[]>()))
        .ReturnsAsync(1);

    // Act
    await _ecbJob.UpdateDatabaseAsync(rates);

    // Assert
    _databaseServiceMock.Verify(db => db.OpenConnectionAsync(), Times.Once);
    _databaseServiceMock.Verify(db => db.BeginTransactionAsync(), Times.Once);
    _databaseServiceMock.Verify(db => db.CommitTransactionAsync(), Times.Once);
    _databaseServiceMock.Verify(db => db.ExecuteNonQueryAsync(It.IsAny<string>(), It.IsAny<SqlParameter[]>()), Times.Exactly(rates.Count));
    }
  }
