using ECB.API.Entities;
using ECB.API.Services;
using ECB.API.Strategies;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ECB.API.Controllers
  {
  [ApiController]
  [Route("api/wallets")]
  public class WalletController : ControllerBase
    {
    private readonly IWalletService _walletService;

    public WalletController(IWalletService walletService)
      {
      _walletService = walletService ?? throw new ArgumentNullException(nameof(walletService));
      }

    /// <summary>
    /// Creates a new wallet.
    /// </summary>
    /// <param name="wallet">The wallet to create.</param>
    /// <returns>A CreatedAtAction result with the created wallet.</returns>
    [HttpPost]
    public async Task<IActionResult> CreateWallet([FromBody] Wallet wallet)
      {
      var createdWallet = await _walletService.CreateWalletAsync(wallet);
      return CreatedAtAction(
          nameof(GetWalletBalance),
          new { walletId = createdWallet.Id },
          createdWallet
      );
      }

    /// <summary>
    /// Gets the balance of a wallet.
    /// </summary>
    /// <param name="walletId">The ID of the wallet.</param>
    /// <param name="currency">The currency to get the balance in.</param>
    /// <returns>An Ok result with the wallet balance, or NotFound if the wallet is not found.</returns>
    [HttpGet("{walletId}")]
    public async Task<IActionResult> GetWalletBalance(
        long walletId,
        [FromQuery] string currency)
      {
      try
        {
        var balance = await _walletService.GetBalanceAsync(walletId, currency);

        var wallet = new Wallet(walletId, currency, balance);

        return Ok(wallet);
        }
      catch (Exception)
        {
        return NotFound("Wallet not found");
        }
      }

    /// <summary>
    /// Adjusts the balance of a wallet.
    /// </summary>
    /// <param name="walletId">The ID of the wallet.</param>
    /// <param name="amount">The amount to adjust the balance by.</param>
    /// <param name="currency">The currency of the amount.</param>
    /// <param name="strategy">The strategy to use for adjusting the balance.</param>
    /// <returns>An Ok result if the balance is adjusted successfully, BadRequest if there are insufficient funds or the amount is invalid, or StatusCode 500 if an error occurs.</returns>
    [HttpPost("{walletId}/adjustbalance")]
    public async Task<IActionResult> AdjustBalance(
        long walletId,
        [FromQuery] decimal amount,
        [FromQuery] string currency,
        [FromQuery] string strategy
    )
      {
      try
        {
        if (amount <= 0) return BadRequest("Amount must be positive");

        IBalanceStrategy balanceStrategy = strategy.ToLower() switch
          {
            "addfundsstrategy" => new AddFundsStrategy(),
            "subtractfundsstrategy" => new SubtractFundsStrategy(),
            "forcesubtractfundsstrategy" => new ForceSubtractFundsStrategy(),
            _ => throw new ArgumentException("Invalid strategy")
            };

        await _walletService.AdjustBalanceAsync(walletId, amount, currency, balanceStrategy);

        return Ok("Balance adjusted successfully");
        }
      catch (InvalidOperationException ex) when (ex.Message == "Insufficient funds")
        {
        return BadRequest("Insufficient funds");
        }
      catch (Exception)
        {
        return StatusCode(500, "An error occurred while adjusting the balance");
        }
      }
    }
  }
