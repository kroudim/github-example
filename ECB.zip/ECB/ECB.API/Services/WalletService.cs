using ECB.API.DbContexts;
using ECB.API.Entities;
using ECB.API.Strategies;
using Microsoft.EntityFrameworkCore;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Text;

namespace ECB.API.Services
  {
  public class WalletService : IWalletService
    {
    private readonly ECBContext _context;

    public WalletService(ECBContext context)
      {
      _context = context;
      }

    public async Task<Wallet> CreateWalletAsync(Wallet wallet)
      {
      _context.Wallets.Add(wallet);
      await _context.SaveChangesAsync();
      return wallet;
      }

    public async Task<decimal> GetBalanceAsync(long walletId, string currency)
      {
      var wallet = await _context.Wallets.FindAsync(walletId);
      if (wallet == null) throw new KeyNotFoundException("Wallet not found");

      if (wallet.Currency == currency) return wallet.Balance;

      return ConvertCurrency(wallet.Balance, wallet.Currency, currency);
      }

    public async Task AdjustBalanceAsync(long walletId, decimal amount, string currency, IBalanceStrategy strategy)
      {
      var wallet = await _context.Wallets.FindAsync(walletId);
      if (wallet == null) throw new KeyNotFoundException("Wallet not found");

      if (wallet.Currency != currency) amount = ConvertCurrency(amount, currency, wallet.Currency);

      strategy.Adjust(wallet, amount);

      await _context.SaveChangesAsync();
      }

    private decimal ConvertCurrency(decimal amount, string fromCurrency, string toCurrency)
      {
      // Mock conversion rate, should be replaced with actual exchange rates.
      return amount * 1.1m;
      }
    }
  }
