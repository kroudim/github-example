using ECB.API.Entities;
using ECB.API.Strategies;
using System.Threading.Tasks;

namespace ECB.API.Services
  {
  public interface IWalletService
    {
    Task<Wallet> CreateWalletAsync(Wallet wallet);
    Task<decimal> GetBalanceAsync(long walletId, string currency);
    Task AdjustBalanceAsync(long walletId, decimal amount, string currency, IBalanceStrategy strategy);
    }
  }
