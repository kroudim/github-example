using ECB.API.Entities;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace ECB.API.DbContexts
  {
  public class ECBContext : DbContext
    {
    public DbSet<CurrencyRate> CurrencyRates { get; set; } = null!;
    public DbSet<Wallet> Wallets { get; set; } = null!;

    public ECBContext(DbContextOptions<ECBContext> options)
            : base(options)
      {

      }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
      {
      modelBuilder.Entity<CurrencyRate>()
       .HasData(
         new CurrencyRate("USD", 1.0360m, DateTime.Now)
               {
               Id = 1
               },
         new CurrencyRate("JPY", 157.95m, DateTime.Now)
               {
               Id = 2
           },
         new CurrencyRate("PLN", 4.2065m, DateTime.Now)
           { 
               Id = 3
           });

      modelBuilder.Entity<Wallet>()
       .HasData(
         new Wallet(1,"USD", 1 ),
 
         new Wallet(2, "JPY", 2),
 
         new Wallet(3, "PLN", 3)
               );


      base.OnModelCreating(modelBuilder);
      }

    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //{
    //    optionsBuilder.UseSqlite("connectionstring");
    //    base.OnConfiguring(optionsBuilder);
    //}
    }
  }
