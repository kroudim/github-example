using ECB.API.Entities;
using Microsoft.Data.SqlClient;

namespace ECB.WorkerService
  {
  public class ECBJob :IHostedService, IDisposable
    {
    private readonly ILogger<ECBJob> _logger;
    private readonly IECBService _ecbService;
    private readonly IDatabaseService _databaseService;
    private readonly double _interval;

    public ECBJob(ILogger<ECBJob> logger, IECBService ecbService, IDatabaseService databaseService, double interval)
      {
      _logger = logger;
      _ecbService = ecbService;
      _databaseService = databaseService;
      _interval = interval;
      }

    public async Task StartAsync(CancellationToken stoppingToken)
      {
      while (!stoppingToken.IsCancellationRequested)
        {
        _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
        await DoWorkAsync();
        await Task.Delay(TimeSpan.FromMinutes(_interval), stoppingToken);
        }
      }

    public async Task DoWorkAsync()
      {
      var rates = await _ecbService.GetExchangeRatesAsync();
      await UpdateDatabaseAsync(rates);
      }

    public async Task UpdateDatabaseAsync(List<CurrencyRate> rates)
      {
      await _databaseService.OpenConnectionAsync();
      await _databaseService.BeginTransactionAsync();
      try
        {
        foreach (var rate in rates)
          {
          string mergeQuery = @"MERGE INTO CurrencyRates AS target
                                             USING (SELECT @Currency AS Currency, @Rate AS Rate, @Date AS Date) AS source
                                             ON target.Currency = source.Currency AND target.Date = source.Date
                                             WHEN MATCHED THEN
                                                 UPDATE SET target.Rate = source.Rate
                                             WHEN NOT MATCHED THEN
                                                 INSERT (Currency, Rate, Date) VALUES (source.Currency, source.Rate, source.Date);";
          var parameters = new[]
          {
                    new SqlParameter("@Currency", rate.Currency),
                    new SqlParameter("@Rate", rate.Rate),
                    new SqlParameter("@Date", rate.Date)
                };
          await _databaseService.ExecuteNonQueryAsync(mergeQuery, parameters);
          }
        await _databaseService.CommitTransactionAsync();
        }
      catch
        {
        await _databaseService.RollbackTransactionAsync();
        throw;
        }
      }

    public Task StopAsync(CancellationToken cancellationToken)
      {
      _logger.LogInformation("ECBJob is stopping.");
      //_timer?.Change(Timeout.Infinite, 0);
      return Task.CompletedTask;
      }

    public void Dispose()
      {

      }
    }
  }