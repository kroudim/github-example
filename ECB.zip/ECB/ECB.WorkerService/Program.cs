using ECB.GateWay;
using ECB.WorkerService;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var builder = Host.CreateApplicationBuilder(args);

// Add configuration to the builder
builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
var connectionString = builder.Configuration.GetConnectionString("ECBRatesConnectionString");
var intervalString = builder.Configuration["ECBRatesInterval"];

if (!double.TryParse(intervalString, out double interval))
  {
  throw new InvalidOperationException("ECBRatesInterval is not a valid double.");
  }

builder.Services.AddHttpClient<ECBService>();
builder.Services.AddSingleton<IDatabaseService>(provider => new DatabaseService(connectionString));
builder.Services.AddHostedService<ECBJob>(provider =>
{
  var logger = provider.GetRequiredService<ILogger<ECBJob>>();
  var ecbService = provider.GetRequiredService<ECBService>();
  var databaseService = provider.GetRequiredService<IDatabaseService>();
  return new ECBJob(logger, ecbService, databaseService, interval);
});

var host = builder.Build();
host.Run();
