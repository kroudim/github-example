using Microsoft.Data.SqlClient;

namespace ECB.WorkerService
  {
  public class DatabaseService : IDatabaseService
    {
    private readonly string _connectionString;
    private SqlConnection _connection;
    private SqlTransaction _transaction;

    public DatabaseService(string connectionString)
      {
      _connectionString = connectionString;
      }

    public async Task OpenConnectionAsync()
      {
      _connection = new SqlConnection(_connectionString);
      await _connection.OpenAsync();
      }

    public Task BeginTransactionAsync()
      {
      _transaction = _connection.BeginTransaction();
      return Task.CompletedTask;
      }

    public Task CommitTransactionAsync()
      {
      _transaction.Commit();
      return Task.CompletedTask;
      }

    public Task RollbackTransactionAsync()
      {
      _transaction.Rollback();
      return Task.CompletedTask;
      }

    public async Task<int> ExecuteNonQueryAsync(string commandText, params SqlParameter[] parameters)
      {
      using (var command = new SqlCommand(commandText, _connection, _transaction))
        {
        command.Parameters.AddRange(parameters);
        return await command.ExecuteNonQueryAsync();
        }
      }
    }
  }
